function [A, idx] = distance_kNN(B, knn)
[A, idx] = mink_new(B, knn, 2, 'sorting', false);%idx的每一行对应着B每一行最小k个元素的原始位置（也就是在B每一行出现的位置，因为B(9,:)中B(9,7)也属于最小的k个元素，所以idx(9,1)=7,idx(9,2)=9）
n = size(A, 1);
%矩阵A存储着对应最小knn个元素的值

% adjacency_matrix = zeros(n,n);
% for i=1:n
%     adjacency_matrix(i, idx(i,:)) = A(i, :);
% end
% A = sparse(adjacency_matrix);

rowidx = ones(knn, n) .* [1:n];
A = sparse(rowidx, idx', A', n, n);

% A = max(A, A');
A = (A + A')/2;
% A = power(A .* A', 1/2);
end