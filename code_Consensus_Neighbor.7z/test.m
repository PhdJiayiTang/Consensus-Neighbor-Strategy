clc
clear
% Data={'3Sources','ALOI','BBCSport','CiteSeer','UCI_Digits'};
% load('D:\BBC\ConsistentGraphLearning-master\data\bbcsport2v.mat');
% Data={'BBCSport','CiteSeer','Reuters','Reuters_21578','MSRC_v1','NUS_WIDE'};
% i=6;
% load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Data{i},'.mat'));
% X=fea;
% Y=gt;
% if i<=6
%     type='cosine';
% else
%     type='euclidean';
% end
% data={'3sources','ALOI-100','AwA_fea',...
%     'BDGP_fea','Caltech101-7','Caltech101-20','Caltech101-all_fea',...
%     'CCV','Handwritten_numerals','MSRCV1','ORL_mtv','SUNRGBD_fea',...
%     'WebKB_2views','WebKB_cor2views_cornell','Wiki_fea',...
%     'WikipediaArticles','yaleA_3view'};
% i=2;
% if i<=8 && i>=5
%     type='cosine';
% else
%     type='euclidean';
% end
%%
%时间
Data={'ALOI-100','BDGP_fea','Caltech101-7','Caltech101-20','MSRCV1','ORL_mtv','WebKB_cor2views_cornell','Wiki_fea','WikipediaArticles','yaleA_3view'};
Name={'ALOI','BDGP','Caltech101-7','Caltech101-20','MSRC-v1','ORL','Webkb','Wiki','Wikipedia','YaleA'};
knn0=[15,50,14,15,15,15,50,15,15,15];
i=4;
% Data={'buaaRnSp','100Leaves','Mfeat'};
% knn0=[5,15,15];
% i=3;
% Name={'Buaa','100Leaves','Hdigit'};
% Data={'BBCSport','CiteSeer','Reuters_21578'};
% knn0=[15,15,50];
% i=1;
% Name={'BBCSport','CiteSeer','Reuters_21578'};
% Data={'Mfeat'};
% knn0=15;
% i=1;
% Name={'Hdigit'};
% for i=1:length(Data)
load(strcat('D:\BBC\multi-view-dataset\',Data{i},'.mat'));
% load(strcat('D:\BBC\multi-view-datasets-master\1-complete-data\',Data{i},'.mat'));
% for lll=1:length(data)
%     if strcmp(Data{i}, 'Mfeat')
%         X{lll}=double(data{lll}');
%     else
%         X{lll}=data{lll}';
%     end
% end
% Y=truth;
% load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Data{i},'.mat'));
% X=fea;
% Y=gt;

if strcmp(Data{i}, 'Caltech101-7') || strcmp(Data{i}, 'Caltech101-20') || strcmp(Data{i}, 'BBCSport') || strcmp(Data{i}, 'Reuters_21578') || strcmp(Data{i}, 'CiteSeer') 
    type='cosine';
else
    type='euclidean';
end
% knn=100  ; 
knn=knn0(i);
beta=1e-6; gamma=1e1;
% [result, ~,time1] = DGF(X, Y, knn, beta, gamma, type);
[result2,A2,Obj,Alpha2] = DCN(X, Y, knn, type);
% [result3, ~,time3] = SGF(X, Y, knn, beta, gamma, type);
[result4,A4,Obj2,Alpha4] = SCN(X, Y, knn, type);
% Time(i,:)=[time1,time2,time3,time4]
% end
%%
% [~,a2]=sort(Obj,'descend');
% if sum(a2'~=[1:length(Obj)])~=0 
%     1
%     Obj=Obj(a2);
% end


k=24;
kk=2;
kkk=10;
kkkk=18;
figure('name',Data{i})
hold on
title(strcat(Name{i},{32},'database'),'fontname','Times New Roman','Fontsize',kkkk);
set(get(gca,'Xlabel'),'FontSize',k);
set(get(gca,'Ylabel'),'FontSize',k);
xlabel('\it iteration','fontname','Times New Roman','Fontsize',kkkk);
grid on
box on
h1=plot(1:length(Obj),log(Obj),'-k','LineWidth',kk,'MarkerSize',kkk);
h2=plot(1:length(Obj2),log(Obj2),'-r','LineWidth',kk,'MarkerSize',kkk);
ylabel('\it ln(loss)','fontname','Times New Roman','Fontsize',kkkk);
h=legend([h1,h2],'DCN','SCN');
set(h,'FontName','Times New Roman','FontSize',12,'FontWeight','normal');
set(gca,'looseInset',[0 0 0 0])
hold off

%%
1
save(strcat('D:\新的算法尝试6\一致邻接矩阵_',Data{i},'_k=',num2str(knn),'.mat'),'result2','A2','Alpha2','result4','A4','Alpha4');
% [nmi, label] = SGF(data, truth, knn, beta, , tol, tol2)
% [nmi, label] = DGF(data, truth, knn, beta, gamma, tol, tol2)
% save(strcat('D:\新的算法尝试6\调参\time4.mat'),'Time');

if strcmp(type, 'euclidean')
    save(strcat('D:\新的算法尝试6\调参\new2_',Data{i},'_k=',num2str(knn),'.mat'),'result','result2','result3','result4');
else
    save(strcat('D:\新的算法尝试6\调参\new2_',Data{i},'_k=',num2str(knn),'_',type,'.mat'),'result','result2','result3','result4');
end
% tabulate(Y)