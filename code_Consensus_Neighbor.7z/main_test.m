clc
clear
% Data={'3Sources','ALOI','BBCSport','CiteSeer','UCI_Digits'};
% load('D:\BBC\ConsistentGraphLearning-master\data\bbcsport2v.mat');
% Data={'BBCSport','CiteSeer','Reuters','Reuters_21578','MSRC_v1','NUS_WIDE'};
% i=6;
% load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Data{i},'.mat'));
% X=fea;
% Y=gt;
% if i<=6
%     type='cosine';
% else
%     type='euclidean';
% end
% data={'3sources','ALOI-100','AwA_fea',...
%     'BDGP_fea','Caltech101-7','Caltech101-20','Caltech101-all_fea',...
%     'CCV','Handwritten_numerals','MSRCV1','ORL_mtv','SUNRGBD_fea',...
%     'WebKB_2views','WebKB_cor2views_cornell','Wiki_fea',...
%     'WikipediaArticles','yaleA_3view'};
% i=2;
% if i<=8 && i>=5
%     type='cosine';
% else
%     type='euclidean';
% end
%%
%时间
Data={'ALOI-100','BDGP_fea','Caltech101-7','Caltech101-20','MSRCV1','ORL_mtv','WebKB_cor2views_cornell','Wiki_fea','WikipediaArticles','yaleA_3view'};
Name={'ALOI','BDGP','Caltech101-7','Caltech101-20','MSRC-v1','ORL','Webkb','Wiki','Wikipedia','YaleA'};
knn0=[15,50,14,15,15,15,50,15,15,15];
i=4;
% Data={'buaaRnSp','100Leaves','Mfeat'};
% knn0=[5,15,15];
% i=3;
% Name={'Buaa','100Leaves','Hdigit'};
% Data={'BBCSport','CiteSeer','Reuters_21578'};
% knn0=[15,15,50];
% i=1;
% Name={'BBCSport','CiteSeer','Reuters_21578'};
% Data={'Mfeat'};
% knn0=15;
% i=1;
% Name={'Hdigit'};
% for i=1:length(Data)
load(strcat('D:\BBC\multi-view-dataset\',Data{i},'.mat'));
% load(strcat('D:\BBC\multi-view-datasets-master\1-complete-data\',Data{i},'.mat'));
% for lll=1:length(data)
%     if strcmp(Data{i}, 'Mfeat')
%         X{lll}=double(data{lll}');
%     else
%         X{lll}=data{lll}';
%     end
% end
% Y=truth;
% load(strcat('D:\BBC\Multi-view_Graph_Learning-master\data\',Data{i},'.mat'));
% X=fea;
% Y=gt;

if strcmp(Data{i}, 'Caltech101-7') || strcmp(Data{i}, 'Caltech101-20') || strcmp(Data{i}, 'BBCSport') || strcmp(Data{i}, 'Reuters_21578') || strcmp(Data{i}, 'CiteSeer') 
    type='cosine';
else
    type='euclidean';
end
knn=knn0(i);
[result2,A2,Obj,Alpha2] = DCN(X, Y, knn, type);
[result4,A4,Obj2,Alpha4] = SCN(X, Y, knn, type);
