function [G,Obj,Alpha]=Consensus_Neighbor(S,lambda)
v=length(S);
n=size(S{1},1);
alpha=ones(1,v)/v;
G=alpha(1) * S{1};
for i=2:v
    temp=S{i};
    G = G + alpha(i) * temp;
end
G=G/v;
if nnz(G)/numel(G) < 0.4  % if W contains a large proportion of zeros, use sparse mode
    G=sparse(G);
else
    G=full(G);
end
[M , M_bar] = Cor_Calculation(S,n,v);

obj1=0;
obj2=0;
for i=1:n
    temp1=M{i};
    obj1=obj1+alpha*temp1*alpha';
    for j=1:v
        temp2=S{j};
        obj2=obj2+norm(alpha(j)*temp2(:,i),2)^2;
    end
end
Obj=lambda*obj1+obj2;
for iter=1:30
    GG=zeros(n,n);
    obj1=0;
    obj2=0;
    Alpha=zeros(n,v);
    for i=1:n
        Error=zeros(v,1);
        temp = M{i};
        temp2 = M_bar{i};
        for j=1:v
            temp3=S{j};
            Error(j,1) = G(:,i)'*temp3(:,i);
        end
        Judge=rcond(lambda*temp+temp2);
        if Judge<10^-16
            fprintf('************* \n')
            solution = pinv(lambda*temp+temp2)*Error;
        else
            solution = (lambda*temp+temp2) \ Error;
        end
        scale=log10(abs(solution));
        if max(scale)<12
            alpha = EProjSimplex_new(solution);
        else
            fprintf('////////// \n')
            alpha=zeros(size(solution));
            alpha(solution==max(solution))=1;
        end
        Alpha(i,:)=alpha;
        obj1=obj1+alpha'*temp*alpha;
        for k=1:v
            temp=S{k};
            GG(:,i)=GG(:,i)+alpha(k)*temp(:,i);
        end
        GG(:,i)=GG(:,i)/v;
        for k2=1:v
            temp=S{k2};
            obj2=obj2+norm(GG(:,i)-alpha(k2)*temp(:,i),2)^2;
        end
    end
    Obj=[ Obj; lambda*obj1+obj2];
    GG=(GG'+GG)/2;
    if nnz(GG)/numel(GG) < 0.4  % if W contains a large proportion of zeros, use sparse mode
        GG=sparse(GG);
    else
        GG=full(GG);
    end
    if norm(GG-G,'fro') < 10^-8
        G=GG;
        break
    end
    G=GG;
end
end

function [ M , M_bar] = Cor_Calculation(S,n,v)

M = cell(n,1);
M_bar = cell(n,1);
for kk= 1:n
    temp=zeros(v,v);
    temp2=zeros(v,1);
    for ii = 1:v
        temp3=S{ii};
        for jj = ii : v
            temp4=S{jj};
            temp5=norm(temp3(:,kk),2);
            temp6=norm(temp4(:,kk),2);
            temp(ii, jj) = temp3(kk,:)*temp4(:,kk)/(temp5*temp6);
            temp(jj, ii) = temp(ii, jj);
        end
        temp2(ii,1)=temp3(:,kk)'*temp3(:,kk);
    end
    M{kk,1} = temp;
    M_bar{kk,1} = sparse(1:v,1:v,temp2);
end

end